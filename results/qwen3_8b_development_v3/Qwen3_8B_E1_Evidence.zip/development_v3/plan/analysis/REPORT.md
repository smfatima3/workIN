# Analysis report
Purpose: development_only. Completed 60/60.
Each independent unit is a complete rollout. Repeated tasks and robot messages are not independent samples.
Rule violations and contact proxies are not injury estimates. Bootstrap intervals may be degenerate at small n; primary binary differences also include conservative intervals.
Inspect uncertainty, clean task cost, missingness, and prior-work controls before making a claim.

## Contrasts
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] poison_effect: n=10, difference=0.000, interval=[-0.334393253826826, 0.334393253826826]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] defense_effect: n=10, difference=-1.000, interval=[-0.9999999999999999, -0.33121349234634795]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] memory_interaction: n=10, difference=0.000, interval=[0.0, 0.0]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] E_vs_A_task_completion: n=10, difference=0.000, interval=[-0.8589388166934752, 0.8589388166934752]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] E_vs_A_safe_task_completion: n=10, difference=1.000, interval=[0.14106118330652484, 1.0]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] E_vs_A_benign_preservation: n=10, difference=0.000, interval=[-0.8589388166934752, 0.8589388166934752]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] E_vs_A_mean_mission_time_s: n=10, difference=5.814, interval=[5.795999999999877, 5.8319999999998755]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] E_vs_A_inspection_count: n=10, difference=2.000, interval=[2.0, 2.0]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] E_vs_A_model_calls: n=10, difference=2.000, interval=[2.0, 2.0]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] F_vs_B_task_completion: n=10, difference=0.000, interval=[-0.8589388166934752, 0.8589388166934752]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] F_vs_B_safe_task_completion: n=10, difference=1.000, interval=[0.14106118330652484, 1.0]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] F_vs_B_benign_preservation: n=10, difference=0.000, interval=[-0.8589388166934752, 0.8589388166934752]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] F_vs_B_mean_mission_time_s: n=10, difference=5.814, interval=[5.795999999999877, 5.8319999999998755]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] F_vs_B_inspection_count: n=10, difference=2.000, interval=[2.0, 2.0]
- ['exclusion', True, 3, 'chain', 1, False, 1.0, None, 4.0] F_vs_B_model_calls: n=10, difference=2.000, interval=[2.0, 2.0]
