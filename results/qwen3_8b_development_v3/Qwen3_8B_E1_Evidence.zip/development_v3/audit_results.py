"""Independent read-only evidence audit; no inference or outcome tuning."""
from pathlib import Path
from collections import defaultdict, Counter
import hashlib, json, sys

root = Path(sys.argv[1])
plan = root / 'plan'
lock = json.loads((plan/'protocol.lock.json').read_text())
manifest = [json.loads(s) for s in (plan/'manifest.jsonl').read_text().splitlines()]
assert len(manifest) == lock['trials'] == 60
groups=defaultdict(list)
decisions=defaultdict(Counter)
calls=[]
observed_actions=[]
failures=list(plan.glob('runs/*/FAILED.json'))
assert not failures, failures
for trial in manifest:
    run=plan/'runs'/trial['trial_id']
    done=json.loads((run/'DONE.json').read_text())
    for relative,h in done['hashes'].items():
        assert hashlib.sha256((run/relative).read_bytes()).hexdigest()==h,relative
    attempt=run/done['attempt']
    result=json.loads((attempt/'result.json').read_text())
    assert not result['fixture']
    groups[trial['condition']].append(result)
    events=[json.loads(s) for s in (attempt/'events.jsonl').read_text().splitlines()]
    for event in events:
        if event['kind']=='model_call':
            assert not event['fixture'] and event['server_model']=='Qwen/Qwen3-8B'
            response=json.loads(event['response_text'])
            assert '<think>' not in event['response_text']
            calls.append(event)
            decisions[trial['condition']][(event['task'], response.get('action',response['belief']))]+=1
            if event['prompt'].get('observation')=='restricted' and event['task']=='act':
                observed_actions.append(response['action'])
        elif event['kind']=='reset':
            assert event['source_removed'] and event['source_disconnected']
            assert not event['transient_context'] and not event['queues']
stats={}
for condition, rows in sorted(groups.items()):
    assert len(rows)==10
    stats[condition]={'n':len(rows)}
    for metric in ('primary_delayed_violation','safe_task_completion','task_completion','false_stores',
                   'residual_false_memories','inspection_count','model_calls','prompt_tokens','completion_tokens'):
        stats[condition][metric]=sum(r[metric] for r in rows)/len(rows)
report={'stage':lock['stage'],'model':lock['model'],'code_hash':lock['code_hash'],
        'completed':len(manifest),'failed':len(failures),'conditions':stats,
        'model_calls':len(calls),'prompt_tokens':sum(e['usage']['prompt_tokens'] for e in calls),
        'completion_tokens':sum(e['usage']['completion_tokens'] for e in calls),
        'actions_after_restricted_observation':dict(Counter(observed_actions)),
        'decision_counts':{k:{str(a):v for a,v in c.items()} for k,c in decisions.items()}}
(root/'independent_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
