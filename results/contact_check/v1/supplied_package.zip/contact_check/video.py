"""Render Scenario A as a side-view schematic from measured MuJoCo positions."""
import json
import shutil
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
traces = json.loads((ROOT / "placement_trace.json").read_text())
font = ImageFont.truetype("DejaVuSans.ttf", 18)
small = ImageFont.truetype("DejaVuSans.ttf", 14)
frames = zip(traces["reference"], traces["challenge"])
cmd = [shutil.which("ffmpeg") or "ffmpeg", "-loglevel", "error", "-y", "-f", "rawvideo",
       "-pix_fmt", "rgb24", "-s", "880x368", "-r", "12", "-i", "-", "-pix_fmt", "yuv420p",
       "-c:v", "libx264", str(ROOT / "placement_pair.mp4")]
with subprocess.Popen(cmd, stdin=subprocess.PIPE) as encoder:
    for pair in frames:
        image = Image.new("RGB", (880, 368), "#f4f6f8")
        d = ImageDraw.Draw(image)
        d.text((18, 10), "Unsafe placement  |  MuJoCo contact calibration", fill="#102639", font=font)
        for i, ((t, x, _, z, hit), title) in enumerate(zip(pair, ["Release over desk", "Release beyond edge"])):
            left = 20 + i * 435
            def point(xval, zval):
                return (left + 235 + xval * 180, 310 - zval * 180)
            d.text((left, 58), title, fill="#102639", font=font)
            d.line((left,310,left+400,310),fill="#82929a",width=2)
            d.rectangle([point(-0.82,0.84),point(0.14,0.76)],fill="#879da4")
            d.rounded_rectangle([point(0.24,0.51),point(0.44,0.01)],radius=17,
                                fill="#da6556" if hit else "#3f777a")
            d.rectangle([point(x-.095,z+.065),point(x+.095,z-.065)],fill="#974d19")
            d.text((left,325), "Contact recorded" if hit else "No contact yet",font=small,fill="#102639")
        d.text((18,35), f"Scripted actions  /  box and person proxy  /  simulation time {pair[0][0]:.2f} s",fill="#43545c",font=small)
        encoder.stdin.write(image.tobytes())
    encoder.stdin.close()
    if encoder.wait():
        raise RuntimeError("ffmpeg failed")
