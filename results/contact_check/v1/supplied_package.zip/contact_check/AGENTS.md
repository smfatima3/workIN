# Experiment integrity

- Keep this calibration separate from original model runs. Preserve original_qwen_event_rows.csv verbatim.
- Run the same geometry, timestep and initial world in both arms. Keep all attempted layouts and variants, including moving-release misses. Version substantive changes in a new output folder.
- Label scripted trials, model-driven trials and physical hardware trials separately. Report every numerator with its denominator and independent unit.
- Require named body-pair contact from the physics engine for a contact claim. Preserve task success, near miss and contact as separate outcomes. Injury requires a validated endpoint.
- In model experiments log source removal, memory provenance, transient-state clearing, observation, command, execution and outcome. Count refusals, failed retention and missing trajectories explicitly.
- Direct PhysHarm reproduction requires native scene definitions and scoring. Cite adaptations as adaptations. Keep recovery-policy work outside this phase.
