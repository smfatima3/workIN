
- 2026-11-05T01:22:39.883066+00:00 User-authorized independent replication; main; one H100; four-hour cap; no hosted OpenAI model; no automatic retries.

- 2026-11-05T01:22:40.813973+00:00 Running tests

- 2026-11-05T01:24:25.934362+00:00 Running upstream_smoke

- 2026-11-05T01:24:31.651297+00:00 FAILED RuntimeError: upstream_smoke exited 1
