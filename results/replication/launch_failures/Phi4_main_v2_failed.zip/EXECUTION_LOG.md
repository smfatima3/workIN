
- 2026-11-05T06:09:12.701676+00:00 User-authorized independent replication; main; one H100; four-hour cap; no hosted OpenAI model; no automatic retries.

- 2026-11-05T06:09:13.895949+00:00 Running tests

- 2026-11-05T06:11:02.211877+00:00 Running upstream_smoke

- 2026-11-05T06:11:16.534471+00:00 FAILED RuntimeError: upstream_smoke exited 1
