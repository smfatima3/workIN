# Delivery verification — 3 November 2026

**Status: software validation passed; scientific experiments not run.**

- 26 automated tests passed on Python 3.12.14 and MuJoCo 3.17.0.
- Tests cover physical footprint geometry, range-limited observations, executed speed/zone rules, independent local shielding, TTL, benign-state-preserving revocation, source removal, transient-state clearing, corrective claims, sensor failure, larger robot graphs, repeated tasks, missing-endpoint errors, and the HTTP JSON/usage/session contract.
- The CLI integration test exercises preparation, concurrent execution, hash validation, safe resume, and deliberate evidence-tampering detection.
- Twelve complete scripted-policy physics rollouts ran through the delivered preparation → execution → validation → analysis → video → result-export workflow. All twelve completed and validated.
- Resuming the completed plan skipped all twelve completed trials after verifying their raw-file hashes.
- Append/finalization behavior was hardened during integration: progress logs are separate from immutable completed event evidence. Truncated evidence is rejected rather than silently repaired or accepted.
- The actual-model HTTP path was tested against a local stub. This validates request/response plumbing only, not a real model's performance or provider compatibility.
- The paired video was verified as H.264, 1440 × 496, 288 frames, 24 seconds. A representative frame and aggregate figure were visually inspected. It is clearly labeled as a scripted software test.
- The algebraic operator example produced spectral radius zero and nonzero finite-horizon hazard weight, as expected for the explicitly supplied finite chain. It is not an empirical estimate.
- The example paired-design calculation returned 132 independent pairs under its stated assumptions. This does not establish an appropriate universal sample size; the actual protocol needs its own design/precision decision.

## Not verified

Real LLM scientific outcomes; model endpoint availability outside the local stub; released CPV/MAPLE/A-MemGuard integration; Isaac Sim/ROS 2/AIM compatibility; camera-based perception; humanoids or manipulation; hardware safety; injury modeling; empirical reproduction thresholds; novelty or venue acceptance.

The included software fixture is for reproducibility checks only. Its values must never be placed in a research abstract or described as actual-model results.
