from .common import digest

class Memory:
    def __init__(self,agent): self.agent=agent; self.items=[]; self.counter=0
    def put(self,belief,parents,origin,task,share=True,kind='zone',value=None):
        self.counter+=1
        item=dict(id=f'{self.agent}:m{self.counter}',agent=self.agent,belief=belief,
                  parents=list(parents),origins=sorted(set(origin)),written_task=task,share=share,kind=kind,value=value)
        self.items.append(item); return item
    def retrieve(self,task,ttl=None):
        return [dict(x) for x in self.items if x['kind']=='zone' and (ttl is None or task-x['written_task']<=ttl)]
    def clear(self): self.items=[]
    def revoke(self,origin):
        old=len(self.items); self.items=[x for x in self.items if origin not in x['origins']]; return old-len(self.items)
    def snapshot(self): return {'agent':self.agent,'items':self.items,'hash':digest(self.items)}

def public(item):
    # Evaluator labels never enter policy prompts. Provenance is runtime metadata, not poison labels.
    return {k:item[k] for k in ['id','belief','written_task','kind','value'] if k in item}
